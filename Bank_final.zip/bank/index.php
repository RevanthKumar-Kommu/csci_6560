<?php
session_start();
if(!isset($_SESSION['userId'])){ header('location:login.php');}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Banking</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <?php require 'assets/autoloader.php'; ?>
  <?php require 'assets/db.php'; ?>
  <?php require 'assets/function.php'; ?>
  
</head>
<style>
  .title-word {
  animation: color-animation 4s linear infinite;
}

.title-word-1 {
  --color-1: #DF8453;
  --color-2: #3D8DAE;
  --color-3: #E4A9A8;
}

.title-word-2 {
  --color-1: #DBAD4A;
  --color-2: #ACCFCB;
  --color-3: #17494D;
}

.title-word-3 {
  --color-1: #ACCFCB;
  --color-2: #E4A9A8;
  --color-3: #ACCFCB;
}

.title-word-4 {
  --color-1: #3D8DAE;
  --color-2: #DF8453;
  --color-3: #E4A9A8;
}

@keyframes color-animation {
  0%    {color: var(--color-1)}
  32%   {color: var(--color-1)}
  33%   {color: var(--color-2)}
  65%   {color: var(--color-2)}
  66%   {color: var(--color-3)}
  99%   {color: var(--color-3)}
  100%  {color: var(--color-1)}
}

/* Here are just some visual styles. 🖌 */

.container {
  display: grid;
  place-items: center;  
  text-align: center;
}

.title {
  font-family: "Montserrat", sans-serif;
  font-weight: 800;
  text-transform: uppercase;
}
.bg-color{
  background-color: #1B1212;
}
</style>
<body style="background: url(images/download4.webp); background-repeat: no-repeat; background-size: 100%; " class="bg-gradient-seconday">
<nav class="navbar navbar-expand-lg navbar-dark bg-color fixed-top">
 <a class="navbar-brand" href="#">
    <img src="images/logo.png" style="object-fit:cover;object-position:center center" width="30" height="30" class="d-inline-block align-top" alt="">
   <!--  <i class="d-inline-block  fa fa-building fa-fw"></i> --><?php echo bankname; ?>
  </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item ">
        <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item ">  <a class="nav-link" href="accounts.php">Accounts</a></li>
      <li class="nav-item ">  <a class="nav-link" href="statements.php">Account Statements</a></li>
      <li class="nav-item ">  <a class="nav-link" href="transfer.php">Funds Transfer</a></li>
      <!-- <li class="nav-item ">  <a class="nav-link" href="profile.php">Profile</a></li> -->


    </ul>
    <?php include 'sideButton.php'; ?>
    
  </div>
</nav><br><br><br><br>
<div class="container">
  <h2 class="title">
    <span class="title-word title-word-1">Welocme </span>
    <span class="title-word title-word-2">To</span>
    <span class="title-word title-word-3">MT</span>
    <span class="title-word title-word-4">Bank</span>
  </h2>
</div>
   <h4 style="color: white ; text-align: center">Start Banking with MT Bank</h3>
   <br><br>
    <center><img src="images/banklogo.png" style="align-items: center"></center>
      
          <div class="card-body" style="position: absolute; bottom:50px; margin-left:470px; width:500px" >
            <a href="accounts.php" class="btn shadow btn-block" style="color:black; border: 2px solid">Account Summary</a>
          </div>

      </div>
         
        <div class="card-body" style="position: absolute; bottom:0px; margin-left:470px; width:500px ">
          <a href="transfer.php" class="btn shadow btn-block" style="color:black; border: 2px solid">Transfer Money</a>
         </div>
      </div>
  
  
</div>
</body>
</html>